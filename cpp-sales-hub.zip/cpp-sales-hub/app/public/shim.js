// Stand-in for claude.ai's window.claude services, backed by this server.
// The hub calls window.claude.use("db" | "user" | "assets" | "downloads" | "sample") exactly as it did on claude.ai.
(function () {
  "use strict";
  const api = async (url, opt = {}) => {
    const r = await fetch(url, { credentials: "same-origin", ...opt, headers: { ...(opt.body && !(opt.body instanceof Blob) ? { "content-type": "application/json" } : {}), ...(opt.headers || {}) } });
    if (r.status === 401) { location.href = "/login.html"; throw { code: "not_granted", message: "Signed out" }; }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw { code: j.code || (r.status === 403 ? "permission_denied" : r.status === 404 ? "not_found" : "unavailable"), message: j.error || "Request failed" };
    return j;
  };
  const meP = api("/api/me");

  /* ---------- live updates ---------- */
  const listeners = new Map(); // col -> Set<fn>
  let ws, wait = 1000;
  function connect() {
    ws = new WebSocket((location.protocol === "https:" ? "wss://" : "ws://") + location.host + "/live");
    ws.onopen = () => { if (wait > 1000) for (const set of listeners.values()) set.forEach(f => f()); wait = 1000; };
    ws.onmessage = e => { try { const { col } = JSON.parse(e.data); listeners.get(col)?.forEach(f => f()); } catch (_) {} };
    ws.onclose = () => { setTimeout(connect, wait); wait = Math.min(wait * 2, 30000); };
  }
  connect();
  const listen = (col, fn) => { let t; const run = () => { clearTimeout(t); t = setTimeout(fn, 60); }; if (!listeners.has(col)) listeners.set(col, new Set()); listeners.get(col).add(run); return () => listeners.get(col)?.delete(run); };

  /* ---------- db ---------- */
  const docSnap = (id, d) => Object.freeze({ id, exists: d != null, data: () => (d == null ? undefined : JSON.parse(JSON.stringify(d))) });
  const qSnap = rows => { const docs = rows.map(r => docSnap(r.id, r.data)); return Object.freeze({ docs, size: docs.length, empty: !docs.length, forEach: f => docs.forEach(f) }); };
  function docRef(path) {
    const col = path.split("/").slice(0, -1).join("/"), id = path.split("/").pop();
    const write = (op, data) => api("/api/doc", { method: "POST", body: JSON.stringify({ op, path, data }) }).then(() => undefined);
    return Object.freeze({
      id, path,
      get: async () => { const r = await api("/api/doc?path=" + encodeURIComponent(path)); return docSnap(id, r.exists ? r.data : null); },
      set: d => write("set", d), update: d => write("update", d), delete: () => write("delete"),
      onSnapshot(cb, err) { let live = true; const pull = () => this.get().then(s => live && cb(s), e => live && err && err(e)); pull(); const off = listen(col.replace(/^data\/users\/me$/, "data/users/" + (meCache?.id || "me")), pull); return () => { live = false; off(); }; },
    });
  }
  let meCache = null; meP.then(m => (meCache = m)).catch(() => {});
  function query(col, w = [], o = null, l = null) {
    const url = () => `/api/q?col=${encodeURIComponent(col)}&w=${encodeURIComponent(JSON.stringify(w))}${o ? "&o=" + encodeURIComponent(JSON.stringify(o)) : ""}${l ? "&l=" + l : ""}`;
    const get = async () => qSnap(await api(url()));
    return Object.freeze({
      where: (f, op, v) => query(col, [...w, [f, op, v]], o, l), orderBy: (f, d) => query(col, w, [f, d || "asc"], l), limit: n => query(col, w, o, n),
      get, doc: id => docRef(col + "/" + id),
      add: async d => { const r = await api("/api/doc", { method: "POST", body: JSON.stringify({ op: "add", col, data: d }) }); return docRef(r.path); },
      onSnapshot(cb, err) { let live = true; const pull = () => get().then(s => live && cb(s), e => live && err && err(e)); pull(); const off = listen(col.replace(/^data\/users\/me$/, "data/users/" + (meCache?.id || "me")), pull); return () => { live = false; off(); }; },
    });
  }
  const db = Object.freeze({ collection: n => query(n), doc: p => docRef(p) });

  /* ---------- user ---------- */
  const user = Object.freeze({
    id: async () => (await meP).id,
    me: async () => { const m = await meP; return { id: m.id, name: m.name, email: m.email, avatarUrl: "" }; },
    profiles: async ids => { const r = ids.length ? await api("/api/users?ids=" + encodeURIComponent(ids.join(","))) : []; const out = {}; for (const id of ids) { const u = r.find(x => x.id === id); out[id] = { id, name: u ? u.name : "", avatarUrl: "" }; } return out; },
    search: async q => (await api("/api/users?q=" + encodeURIComponent(q || ""))).map(u => ({ id: u.id, name: u.name, email: u.email })),
    isOwner: async () => (await meP).level === "owner",
    canEdit: async () => ["owner", "editor"].includes((await meP).level),
    can: async n => { const lv = (await meP).level; return n === "data.write" ? lv !== "viewer" : n === "people.add" ? ["owner", "editor"].includes(lv) : null; },
  });

  /* ---------- files ---------- */
  const assets = Object.freeze({
    upload: async (blob, o = {}) => { const r = await fetch("/api/assets", { method: "PUT", body: blob, headers: { "content-type": o.type || blob.type || "application/octet-stream", "x-file-name": encodeURIComponent(blob.name || "") } }); const j = await r.json().catch(() => ({})); if (!r.ok) throw { code: r.status === 413 ? "too_large" : j.code || "unavailable", message: j.error || "Upload failed" }; return j; },
    list: () => api("/api/assets"), delete: id => api("/api/assets/" + encodeURIComponent(id), { method: "DELETE" }),
  });
  const downloads = Object.freeze({
    save: async ({ filename, data }) => { const b = data instanceof Blob ? data : new Blob([data]); const u = URL.createObjectURL(b), a = document.createElement("a"); a.href = u; a.download = filename || "download"; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 5000); },
  });

  /* ---------- Claude AI ---------- */
  async function sample(input, opts = {}) {
    const r = await api("/api/ai", { method: "POST", body: JSON.stringify({ input, modelTier: opts.modelTier }) });
    opts.onText && opts.onText({ text: r.text, delta: r.text });
    return { text: r.text, truncated: !!r.truncated };
  }
  sample.json = async (input, opts) => { const r = await sample(typeof input === "string" ? input + "\n\nAnswer with JSON only, no other text." : input, opts); const t = r.text.replace(/^```(?:json)?\s*|\s*```$/g, "").trim(); try { return JSON.parse(t); } catch (e) { const m = t.match(/[\[{][\s\S]*[\]}]/); if (m) return JSON.parse(m[0]); throw { code: "bad_json", message: "Claude's answer wasn't JSON", text: r.text }; } };
  sample.limits = async () => ({ images: false });

  const services = { db, user, assets, downloads, sample: null };
  const samp = meP.then(m => (m.ai ? Object.freeze(sample) : null)).catch(() => null);
  window.claude = Object.freeze({ use: async n => (n === "sample" ? samp : n === "db" || n === "user" ? meP.then(() => services[n]).catch(() => null) : services[n] || null) });
  window.__selfHosted = true;
})();
