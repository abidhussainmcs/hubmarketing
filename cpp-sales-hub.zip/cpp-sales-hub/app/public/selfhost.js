// Small changes for running the hub on your own server instead of claude.ai.
(function () {
  "use strict";
  // Log out signs out of this server.
  window.openSignOut = async function () { try { await fetch("/auth/logout", { method: "POST" }); } catch (e) {} location.href = "/login.html"; };
  // Profile menu: add "Change password" and, for Admins, "People and access".
  const _menu = window.openMeMenu;
  if (typeof _menu === "function") window.openMeMenu = openMeMenu = function () {
    _menu.apply(this, arguments);
    const nav = document.querySelector("#mePop .melinks"); if (!nav || nav.querySelector("[data-pwchange]")) return;
    nav.insertAdjacentHTML("beforeend", `<button type="button" data-pwchange=""><svg><use href="#i-gear"/></svg>Change my password</button>` + (myLevel === "owner" || myLevel === "editor" ? `<a href="/admin.html"><svg><use href="#i-leads"/></svg>People and access</a>` : ""));
    const sg = document.querySelector("#mePop .mesign .sm"); if (sg) sg.textContent = "Signed in to CPP's own hub server.";
    const lv = document.querySelector("#mePop .melevel p.sm"); if (lv) lv.textContent = "Access is set by an Admin under People and access.";
  };
  document.addEventListener("click", async e => {
    if (!e.target.closest("[data-pwchange]")) return;
    const cur = prompt("Your current password:"); if (!cur) return;
    const nw = prompt("New password (10+ characters):"); if (!nw) return;
    const r = await fetch("/auth/password", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ current: cur, next: nw }) });
    const j = await r.json().catch(() => ({})); toast(r.ok ? "Password changed" : j.error || "Couldn't change it");
  });
})();
