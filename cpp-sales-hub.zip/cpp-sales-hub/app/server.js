// CPP Sales Hub — self-hosted server.
// Stands in for the services the hub used on claude.ai: database (with live updates), sign-in,
// file storage, Claude AI, and access rules. The hub page itself is unchanged apart from /shim.js.
"use strict";
const express = require("express");
const { Pool } = require("pg");
const { WebSocketServer } = require("ws");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const http = require("http");

const PORT = +process.env.PORT || 8080;
const FILES = process.env.FILES_DIR || "/data/files";
const AI_KEY = process.env.ANTHROPIC_API_KEY || "";
const AI_MODEL = process.env.AI_MODEL || "claude-sonnet-5-5";
const AI_MODEL_QUICK = process.env.AI_MODEL_QUICK || "claude-haiku-5-5";
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
fs.mkdirSync(FILES, { recursive: true });

/* ---------------- database ---------------- */
async function migrate() {
  await pool.query(`
    create table if not exists docs(path text primary key, col text not null, data jsonb not null, updated_at timestamptz not null default now());
    create index if not exists docs_col on docs(col);
    create table if not exists users(id text primary key, email text unique not null, name text not null, level text not null default 'contributor', pass text not null, created_at timestamptz not null default now(), disabled boolean not null default false);
    create table if not exists sessions(token text primary key, user_id text not null references users(id) on delete cascade, expires timestamptz not null);
    create table if not exists assets(id text primary key, type text not null, size int not null, name text, owner text, created_at timestamptz not null default now());
    create table if not exists ai_log(id bigserial primary key, user_id text, model text, in_tokens int, out_tokens int, at timestamptz not null default now());`);
  // First start: load the data exported from the claude.ai hub, and create the owner account.
  const { rows } = await pool.query("select count(*)::int n from docs");
  if (!rows[0].n && fs.existsSync(path.join(__dirname, "seed/seed.json"))) {
    const seed = JSON.parse(fs.readFileSync(path.join(__dirname, "seed/seed.json"), "utf8"));
    for (const d of seed.docs) await put(d.path, d.data, true);
    console.log(`Imported ${seed.docs.length} records from the claude.ai hub.`);
  }
  const fdir = path.join(__dirname, "seed/files"), na = (await pool.query("select count(*)::int n from assets")).rows[0].n;
  if (!na && fs.existsSync(fdir)) {
    const T = { webp: "image/webp", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", pdf: "application/pdf", mp4: "video/mp4" };
    for (const f of fs.readdirSync(fdir)) { const [id, ext] = f.split("."); if (!/^[a-f0-9]{32}$/.test(id)) continue; fs.copyFileSync(path.join(fdir, f), path.join(FILES, id)); await pool.query("insert into assets(id,type,size,name) values($1,$2,$3,$4) on conflict do nothing", [id, T[ext] || "application/octet-stream", fs.statSync(path.join(fdir, f)).size, f]); }
    console.log("Imported supplier logos and files.");
  }
  const email = (process.env.ADMIN_EMAIL || "").toLowerCase().trim();
  if (email) {
    const u = await pool.query("select id from users where email=$1", [email]);
    if (!u.rows.length) {
      if (!process.env.ADMIN_PASSWORD) throw new Error("Set ADMIN_PASSWORD in .env for the first start.");
      // Keep the owner's old claude.ai id so their existing leads, quotes and notes stay theirs.
      const id = process.env.ADMIN_LEGACY_ID || "u_" + crypto.randomBytes(9).toString("hex");
      await pool.query("insert into users(id,email,name,level,pass) values($1,$2,$3,'owner',$4)", [id, email, process.env.ADMIN_NAME || email.split("@")[0], hashPass(process.env.ADMIN_PASSWORD)]);
      console.log(`Created the owner account for ${email}.`);
    }
  }
}
const colOf = p => p.split("/").slice(0, -1).join("/");
const valid = p => typeof p === "string" && /^[A-Za-z0-9_\-.~:@+]+(\/[A-Za-z0-9_\-.~:@+]+)*$/.test(p) && p.split("/").length % 2 === 0 && p.length < 1000;
async function put(p, data, quiet) {
  await pool.query("insert into docs(path,col,data,updated_at) values($1,$2,$3,now()) on conflict(path) do update set data=excluded.data, updated_at=now()", [p, colOf(p), data]);
  if (!quiet) broadcast(colOf(p));
}
async function getDoc(p) { const r = await pool.query("select data from docs where path=$1", [p]); return r.rows[0]?.data ?? null; }

/* ---------------- auth ---------------- */
function hashPass(pw) { const salt = crypto.randomBytes(16).toString("hex"); return salt + ":" + crypto.scryptSync(pw, salt, 32).toString("hex"); }
function checkPass(pw, stored) { const [salt, h] = String(stored).split(":"); if (!salt || !h) return false; const x = crypto.scryptSync(pw, salt, 32).toString("hex"); return crypto.timingSafeEqual(Buffer.from(x), Buffer.from(h)); }
const cookieOf = req => Object.fromEntries((req.headers.cookie || "").split(";").map(c => c.trim().split("=")).filter(x => x[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join("="))]));
async function userFromReq(req) {
  const t = cookieOf(req).hub_session; if (!t) return null;
  const r = await pool.query("select u.id,u.email,u.name,u.level from sessions s join users u on u.id=s.user_id where s.token=$1 and s.expires>now() and not u.disabled", [t]);
  return r.rows[0] || null;
}
const isAdmin = u => u && (u.level === "owner" || u.level === "editor");
const loginTries = new Map();

/* ---------------- access rules (enforced here, not just in the page) ---------------- */
const ADMIN_WRITE = ["members", "settings", "invites"];
function canRead(u, p) { const s = p.split("/"); if (s[0] === "data" && s[1] === "users") return s[2] === u.id; return true; }
function canWrite(u, p, op) {
  if (u.level === "viewer") return false;
  const s = p.split("/");
  if (s[0] === "data" && s[1] === "users") return s[2] === u.id;
  if (ADMIN_WRITE.includes(s[0])) return isAdmin(u);
  if (s[0] === "audit") return op === "set"; // the change log is write-once: nobody edits or deletes it
  return true;
}
const meify = (u, p) => String(p || "").replace(/^data\/users\/me(\/|$)/, `data/users/${u.id}$1`);

/* ---------------- app ---------------- */
const app = express();
app.disable("x-powered-by");
app.use((req, res, next) => { res.setHeader("X-Content-Type-Options", "nosniff"); res.setHeader("Referrer-Policy", "same-origin"); next(); });
app.use("/auth", express.json({ limit: "100kb" }));
app.use("/api", express.json({ limit: "2mb" }));

app.post("/auth/login", async (req, res) => {
  const ip = req.socket.remoteAddress, n = (loginTries.get(ip) || 0) + 1; loginTries.set(ip, n); setTimeout(() => loginTries.set(ip, Math.max(0, (loginTries.get(ip) || 1) - 1)), 15 * 60e3);
  if (n > 20) return res.status(429).json({ error: "Too many tries. Wait 15 minutes." });
  const { email, password } = req.body || {};
  const r = await pool.query("select * from users where email=$1 and not disabled", [String(email || "").toLowerCase().trim()]);
  const u = r.rows[0];
  if (!u || !checkPass(String(password || ""), u.pass)) return res.status(401).json({ error: "That email and password don't match." });
  const token = crypto.randomBytes(32).toString("hex");
  await pool.query("insert into sessions(token,user_id,expires) values($1,$2,now()+interval '30 days')", [token, u.id]);
  res.setHeader("Set-Cookie", `hub_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${30 * 86400}${req.secure || req.headers["x-forwarded-proto"] === "https" ? "; Secure" : ""}`);
  res.json({ ok: true });
});
app.post("/auth/logout", async (req, res) => { const t = cookieOf(req).hub_session; if (t) await pool.query("delete from sessions where token=$1", [t]); res.setHeader("Set-Cookie", "hub_session=; Path=/; Max-Age=0"); res.json({ ok: true }); });
app.post("/auth/password", async (req, res) => {
  const u = await userFromReq(req); if (!u) return res.status(401).end();
  const { current, next: nw } = req.body || {}; const r = await pool.query("select pass from users where id=$1", [u.id]);
  if (!checkPass(String(current || ""), r.rows[0].pass)) return res.status(400).json({ error: "Your current password isn't right." });
  if (String(nw || "").length < 10) return res.status(400).json({ error: "Use at least 10 characters." });
  await pool.query("update users set pass=$1 where id=$2", [hashPass(nw), u.id]); res.json({ ok: true });
});

// Everything below needs a signed-in person.
const need = async (req, res, next) => { const u = await userFromReq(req).catch(() => null); if (!u) { if (req.path.startsWith("/api") || req.path.startsWith("/_blob")) return res.status(401).json({ error: "Sign in first" }); return res.redirect("/login.html"); } req.user = u; next(); };
app.get("/login.html", (req, res) => res.sendFile(path.join(__dirname, "public/login.html")));
app.get("/hub-logo.png", (req, res) => res.sendFile(path.join(__dirname, "public/hub-logo.png")));
app.use(need);
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "public/index.html")));
app.use(express.static(path.join(__dirname, "public"), { index: false, setHeaders: r => r.setHeader("Cache-Control", "no-cache") }));

app.get("/api/me", (req, res) => res.json({ id: req.user.id, name: req.user.name, email: req.user.email, level: req.user.level, ai: !!AI_KEY }));
app.get("/api/users", async (req, res) => {
  const ids = String(req.query.ids || "").split(",").filter(Boolean), q = String(req.query.q || "").toLowerCase();
  const r = ids.length ? await pool.query("select id,name,email from users where id = any($1)", [ids]) : await pool.query("select id,name,email from users where not disabled and (lower(name) like $1 or lower(email) like $1) order by name limit 20", ["%" + q + "%"]);
  res.json(r.rows);
});

// Query a collection. Filters run here so access rules apply.
app.get("/api/q", async (req, res) => {
  const col = meify(req.user, req.query.col); if (!col || col.split("/").length % 2 !== 1) return res.status(400).json({ error: "bad collection" });
  if (!canRead(req.user, col + "/x")) return res.json([]);
  const where = JSON.parse(req.query.w || "[]"), order = JSON.parse(req.query.o || "null"), lim = Math.min(5000, +req.query.l || 5000);
  const r = await pool.query("select path,data from docs where col=$1", [col]);
  let rows = r.rows.map(x => ({ id: x.path.split("/").pop(), data: x.data }));
  for (const [f, op, v] of where) rows = rows.filter(({ data }) => { const a = data?.[f]; switch (op) { case "==": return a === v; case "!=": return a !== v; case "<": return a < v; case "<=": return a <= v; case ">": return a > v; case ">=": return a >= v; case "in": return (v || []).includes(a); case "not-in": return !(v || []).includes(a); case "array-contains": return Array.isArray(a) && a.includes(v); default: return true; } });
  if (order) rows.sort((x, y) => { const a = x.data?.[order[0]], b = y.data?.[order[0]]; return (a > b ? 1 : a < b ? -1 : 0) * (order[1] === "desc" ? -1 : 1); });
  res.json(rows.slice(0, lim));
});
app.get("/api/doc", async (req, res) => { const p = meify(req.user, req.query.path); if (!valid(p)) return res.status(400).json({ error: "bad path" }); if (!canRead(req.user, p)) return res.json({ exists: false }); const d = await getDoc(p); res.json(d == null ? { exists: false } : { exists: true, data: d }); });
app.post("/api/doc", async (req, res) => {
  const { op, data } = req.body || {}; let p = meify(req.user, req.body?.path);
  if (op === "add") { const col = meify(req.user, req.body.col); p = col + "/" + crypto.randomBytes(10).toString("base64url"); }
  if (!valid(p)) return res.status(400).json({ error: "bad path", code: "invalid_argument" });
  if (!canWrite(req.user, p, op === "add" ? "set" : op)) return res.status(403).json({ error: "You don't have permission to change this.", code: "permission_denied" });
  if (op === "set" || op === "add") { if (!data || typeof data !== "object") return res.status(400).end(); await put(p, data); }
  else if (op === "update") { const cur = await getDoc(p); if (cur == null) return res.status(404).json({ error: "not found", code: "not_found" }); await put(p, { ...cur, ...data }); }
  else if (op === "delete") { await pool.query("delete from docs where path=$1", [p]); broadcast(colOf(p)); }
  else return res.status(400).end();
  res.json({ ok: true, id: p.split("/").pop(), path: p });
});

// Files: library videos and PDFs, claim photos, profile pictures.
const TYPES = /^(image\/(png|jpeg|gif|webp|svg\+xml)|video\/(mp4|webm)|application\/pdf|text\/(csv|markdown|plain)|application\/json)$/;
app.put("/api/assets", express.raw({ type: "*/*", limit: "50mb" }), async (req, res) => {
  if (req.user.level === "viewer") return res.status(403).json({ code: "not_granted" });
  const type = String(req.headers["content-type"] || "").split(";")[0]; if (!TYPES.test(type)) return res.status(415).json({ code: "unsupported_type" });
  const id = crypto.randomBytes(16).toString("hex"); fs.writeFileSync(path.join(FILES, id), req.body);
  await pool.query("insert into assets(id,type,size,name,owner) values($1,$2,$3,$4,$5)", [id, type, req.body.length, String(req.headers["x-file-name"] || "").slice(0, 200), req.user.id]);
  res.json({ id, url: "/_blob/" + id, sizeBytes: req.body.length, contentType: type });
});
app.get("/api/assets", async (req, res) => { const r = await pool.query("select id,type contentType,size sizeBytes,name,owner,created_at from assets order by created_at desc"); res.json({ assets: r.rows.map(a => ({ ...a, url: "/_blob/" + a.id })) }); });
app.delete("/api/assets/:id", async (req, res) => { const r = await pool.query("select owner from assets where id=$1", [req.params.id]); if (!r.rows[0]) return res.json({ ok: true }); if (r.rows[0].owner !== req.user.id && !isAdmin(req.user)) return res.status(403).end(); await pool.query("delete from assets where id=$1", [req.params.id]); fs.rmSync(path.join(FILES, req.params.id), { force: true }); res.json({ ok: true }); });
app.get("/_blob/:id", async (req, res) => { if (!/^[a-f0-9]{32}$/.test(req.params.id)) return res.status(404).end(); const r = await pool.query("select type from assets where id=$1", [req.params.id]); if (!r.rows[0]) return res.status(404).end(); res.setHeader("Content-Type", r.rows[0].type); if (r.rows[0].type === "image/svg+xml") res.setHeader("Content-Security-Policy", "script-src 'none'"); res.sendFile(path.join(FILES, req.params.id)); });

// Claude AI. The API key stays on the server; the page never sees it.
app.post("/api/ai", async (req, res) => {
  if (!AI_KEY) return res.status(503).json({ code: "not_granted", error: "Add ANTHROPIC_API_KEY to .env to turn on Claude features." });
  const { input, modelTier, maxTokens } = req.body || {};
  const messages = typeof input === "string" ? [{ role: "user", content: input }] : Array.isArray(input) ? input.map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content) })) : null;
  if (!messages) return res.status(400).json({ code: "bad_request" });
  const model = modelTier === "quick" ? AI_MODEL_QUICK : AI_MODEL;
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers: { "x-api-key": AI_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" }, body: JSON.stringify({ model, max_tokens: Math.min(+maxTokens || 2000, 8000), messages }) });
    const j = await r.json();
    if (!r.ok) return res.status(502).json({ code: r.status === 429 ? "rate_limited" : "upstream_error", error: j?.error?.message || "Claude didn't answer" });
    pool.query("insert into ai_log(user_id,model,in_tokens,out_tokens) values($1,$2,$3,$4)", [req.user.id, model, j.usage?.input_tokens || 0, j.usage?.output_tokens || 0]).catch(() => {});
    res.json({ text: (j.content || []).filter(c => c.type === "text").map(c => c.text).join(""), truncated: j.stop_reason === "max_tokens" });
  } catch (e) { res.status(502).json({ code: "upstream_error", error: "Couldn't reach Claude" }); }
});

// People and access (Owners and Editors). This replaces claude.ai's Share menu.
const adminOnly = (req, res, next) => isAdmin(req.user) ? next() : res.status(403).json({ error: "Admins only" });
app.get("/api/admin/users", adminOnly, async (req, res) => { const r = await pool.query("select id,email,name,level,disabled,created_at from users order by name"); res.json(r.rows); });
app.post("/api/admin/users", adminOnly, async (req, res) => {
  const { email, name, level, password } = req.body || {}; const lv = ["owner", "editor", "contributor", "viewer"].includes(level) ? level : "contributor";
  if (lv === "owner" && req.user.level !== "owner") return res.status(403).json({ error: "Only an Owner can add another Owner." });
  if (!/^\S+@\S+\.\S+$/.test(String(email || "")) || !name || String(password || "").length < 10) return res.status(400).json({ error: "Name, a valid email and a temporary password of 10+ characters are required." });
  try { const id = "u_" + crypto.randomBytes(9).toString("hex"); await pool.query("insert into users(id,email,name,level,pass) values($1,$2,$3,$4,$5)", [id, email.toLowerCase().trim(), name, lv, hashPass(password)]); res.json({ ok: true, id }); }
  catch (e) { res.status(400).json({ error: "Someone with that email already exists." }); }
});
app.patch("/api/admin/users/:id", adminOnly, async (req, res) => {
  const { level, disabled, password, name } = req.body || {}; const t = (await pool.query("select level from users where id=$1", [req.params.id])).rows[0]; if (!t) return res.status(404).end();
  if ((t.level === "owner" || level === "owner") && req.user.level !== "owner") return res.status(403).json({ error: "Only an Owner can change an Owner." });
  if (req.params.id === req.user.id && (disabled || (level && level !== req.user.level))) return res.status(400).json({ error: "You can't lock yourself out." });
  if (level) await pool.query("update users set level=$1 where id=$2", [level, req.params.id]);
  if (typeof disabled === "boolean") { await pool.query("update users set disabled=$1 where id=$2", [disabled, req.params.id]); if (disabled) await pool.query("delete from sessions where user_id=$1", [req.params.id]); }
  if (password) { if (String(password).length < 10) return res.status(400).json({ error: "Use at least 10 characters." }); await pool.query("update users set pass=$1 where id=$2", [hashPass(password), req.params.id]); }
  if (name) await pool.query("update users set name=$1 where id=$2", [name, req.params.id]);
  res.json({ ok: true });
});
app.get("/api/admin/ai-usage", adminOnly, async (req, res) => { const r = await pool.query("select u.name, l.model, count(*)::int calls, sum(in_tokens)::int in_tokens, sum(out_tokens)::int out_tokens from ai_log l left join users u on u.id=l.user_id where l.at > now()-interval '30 days' group by 1,2 order by 3 desc"); res.json(r.rows); });
app.get("/api/admin/backup", adminOnly, async (req, res) => { const r = await pool.query("select path,data from docs where path not like 'data/users/%' order by path"); res.setHeader("Content-Disposition", `attachment; filename="cpp-hub-backup-${new Date().toISOString().slice(0, 10)}.json"`); res.json({ exportedAt: new Date().toISOString(), docs: r.rows }); });

/* ---------------- live updates ---------------- */
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });
server.on("upgrade", async (req, sock, head) => {
  if (req.url !== "/live") return sock.destroy();
  const u = await userFromReq(req).catch(() => null); if (!u) return sock.destroy();
  wss.handleUpgrade(req, sock, head, ws => { ws.user = u; wss.emit("connection", ws); });
});
function broadcast(col) { const s = col.split("/"); for (const ws of wss.clients) { if (ws.readyState !== 1) continue; if (s[0] === "data" && s[1] === "users" && s[2] !== ws.user.id) continue; ws.send(JSON.stringify({ col })); } }
setInterval(() => { for (const ws of wss.clients) if (ws.readyState === 1) ws.ping(); }, 30e3);
setInterval(() => pool.query("delete from sessions where expires<now()").catch(() => {}), 3600e3);

(async () => {
  for (let i = 0; i < 30; i++) { try { await pool.query("select 1"); break; } catch (e) { console.log("Waiting for the database…"); await new Promise(r => setTimeout(r, 2000)); } }
  await migrate();
  server.listen(PORT, () => console.log(`CPP Sales Hub is running on port ${PORT}`));
})().catch(e => { console.error(e.message); process.exit(1); });
